from types import SimpleNamespace
from unittest.mock import patch
import frappe
from frappe.tests.utils import FrappeTestCase
from omc_app import permissions
from omc_app.api import document_upload, mobile
from omc_app.setup.roles import BUSINESS_PARTNER_ROLE, CONSULTANT_ROLE, DOCUMENT_REVIEWER_ROLE, FINANCE_REVIEWER_ROLE, MANAGER_BLOCKED_DOCTYPES, MANAGER_ROLE, SUPPORT_AGENT_ROLE, TAX_ASSOCIATE_ROLE

class TestPermissionSchemaContract(FrappeTestCase):

    def test_support_ticket_scope_fields_exist(self):
        meta = frappe.get_meta('OMC Support Ticket')
        for fieldname in ('customer_profile', 'reference_service_request', 'assigned_to'):
            with self.subTest(fieldname=fieldname):
                self.assertTrue(meta.has_field(fieldname))

class TestPermissionQueryConditions(FrappeTestCase):

    def _query_for(self, query_function, role, user='worker@example.com'):
        with patch.object(permissions, '_roles', return_value={role}):
            return query_function(user=user)

    def test_customer_service_request_query_includes_own_identity(self):
        with patch.object(permissions, '_roles', return_value=set()):
            query = permissions.service_request_query(user='customer@example.com')
        self.assertIn('requested_for_customer', query)
        self.assertIn('submitted_by_user', query)
        self.assertIn('linked_app_user', query)
        self.assertIn('customer@example.com', query)

    def test_field_role_query_includes_live_referral_scope(self):
        query = self._query_for(permissions.service_request_query, CONSULTANT_ROLE, user='consultant@example.com')
        self.assertIn('referral_owner', query)
        self.assertIn('referral_record', query)
        self.assertIn('referral_assistance_consent', query)
        self.assertIn('is_active', query)
        self.assertIn('assigned_staff', query)

    def test_document_reviewer_has_document_domain_only(self):
        document_query = self._query_for(permissions.service_document_query, DOCUMENT_REVIEWER_ROLE)
        payment_query = self._query_for(permissions.service_payment_query, DOCUMENT_REVIEWER_ROLE)
        self.assertEqual(document_query, '')
        self.assertEqual(payment_query, '1=0')

    def test_finance_reviewer_has_payment_domain_only(self):
        payment_query = self._query_for(permissions.service_payment_query, FINANCE_REVIEWER_ROLE)
        document_query = self._query_for(permissions.service_document_query, FINANCE_REVIEWER_ROLE)
        self.assertEqual(payment_query, '')
        self.assertEqual(document_query, '1=0')

    def test_support_agent_has_support_and_lead_domains(self):
        support_query = self._query_for(permissions.support_ticket_query, SUPPORT_AGENT_ROLE)
        lead_query = self._query_for(permissions.lead_query, SUPPORT_AGENT_ROLE)
        self.assertEqual(support_query, '')
        self.assertEqual(lead_query, '')

class TestManagerConfigurationBoundary(FrappeTestCase):

    def test_manager_blocked_doctypes_cover_configuration_surfaces(self):
        expected = {'OMC Branding Settings', 'OMC Mobile Settings', 'OMC Mobile Quick Action', 'OMC Service', 'OMC Service Category', 'OMC Service Form Field', 'OMC Service Required Document', 'OMC Service Stage Template', 'OMC App Banner', 'OMC Onboarding Slide', 'OMC FAQ', 'OMC Knowledge Article', 'OMC Announcement', 'OMC Expense Category', 'OMC Payment Account', 'OMC Tax Adjustment Rule', 'OMC Tax Calculator Settings', 'OMC Tax Input Field', 'OMC Tax Result Insight', 'OMC Tax Year'}
        self.assertTrue(expected.issubset(MANAGER_BLOCKED_DOCTYPES))

class TestMobileServiceCaseScope(FrappeTestCase):

    def test_assigned_service_case_scope_returns_only_assigned_names(self):
        capabilities = {'can_view_all_service_cases': False, 'can_view_relevant_service_cases': False, 'can_view_assigned_service_cases': True}
        with patch.object(mobile, '_assigned_record_names', return_value=['SR-ASSIGNED-1', 'SR-ASSIGNED-2']):
            names = mobile._service_case_scope_names(capabilities, user='consultant@example.com')
        self.assertEqual(names, ['SR-ASSIGNED-1', 'SR-ASSIGNED-2'])

    def test_unassigned_service_case_status_update_is_rejected(self):
        capabilities = {'can_update_service_status': False, 'can_update_assigned_service_status': True}
        with patch.object(mobile, '_assert_internal_workspace_access', return_value='consultant@example.com'), patch.object(mobile, '_canonical_capabilities', return_value=capabilities), patch.object(mobile, '_assigned_record_names', return_value=['SR-ASSIGNED']), self.assertRaises(frappe.PermissionError):
            mobile._require_service_case_update_scope('SR-UNASSIGNED')

class TestTaskAssignmentBoundary(FrappeTestCase):

    def _task(self, assigned_to, *, name='TASK-1', is_new=False):
        return SimpleNamespace(assigned_to=assigned_to, name=name, is_new=lambda: is_new)

class TestDocumentAttachmentBoundary(FrappeTestCase):

    def test_cross_service_uploaded_file_reuse_is_rejected(self):
        service_case = SimpleNamespace(name='SR-TARGET')
        uploaded_file = SimpleNamespace(file_name='identity.pdf', file_url='/private/files/identity.pdf', file_size=1024, owner='customer@example.com', attached_to_doctype='OMC Service Request', attached_to_name='SR-OTHER')
        with patch.object(document_upload.frappe.db, 'count', return_value=0), patch.object(document_upload, '_find_uploaded_file', return_value=uploaded_file), patch.object(document_upload, '_current_user', return_value='customer@example.com'), self.assertRaises(frappe.PermissionError):
            document_upload._validate_uploaded_document(service_case, '/private/files/identity.pdf')

class TestNotificationOwnershipBoundary(FrappeTestCase):

    def test_customer_notification_without_matching_profile_is_rejected(self):
        notification = SimpleNamespace(customer_profile='', recipient_user='')
        profile = SimpleNamespace(name='CUST-001')
        with self.assertRaises(frappe.PermissionError):
            mobile._assert_notification_access(notification, user='customer@example.com', profile=profile)

    def test_internal_notification_without_matching_recipient_is_rejected(self):
        notification = SimpleNamespace(customer_profile='', recipient_user='')
        with self.assertRaises(frappe.PermissionError):
            mobile._assert_notification_access(notification, user='support@example.com', profile=None)

    def test_exact_notification_owner_is_allowed(self):
        customer_notification = SimpleNamespace(customer_profile='CUST-001', recipient_user='')
        internal_notification = SimpleNamespace(customer_profile='', recipient_user='support@example.com')
        mobile._assert_notification_access(customer_notification, user='customer@example.com', profile=SimpleNamespace(name='CUST-001'))
        mobile._assert_notification_access(internal_notification, user='support@example.com', profile=None)
